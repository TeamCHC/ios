//
//  AppDelegate.h
//  CoreImageApp
//
//  Created by Hunter Houston on 3/23/14.
//  Copyright (c) 2014 SMU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
