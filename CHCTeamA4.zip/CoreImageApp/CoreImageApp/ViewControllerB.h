//
//  ViewControllerB.h
//  CoreImageApp
//
//  Created by CONNER KNUTSON on 3/23/14.
//  Copyright (c) 2014 SMU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerB : UIViewController

@end
